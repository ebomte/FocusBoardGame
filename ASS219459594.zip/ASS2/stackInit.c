//
// Created by bomte on 03/04/2020.
//

#include "stackInit.h"
#include "startGame.h"
#include "input_output.h"
#include <stdlib.h>
#include <stdio.h>
#include "StackEnd.h"
square moveItemsLeft(square board[8][8], int userRow, int userColumn, int currentNumberOfPieces, player players[2], int playerIndex) {
    square num1_pieces = board[userRow][userColumn - currentNumberOfPieces]; //storing the location of the square we are moving to
    int tempNumPieces = num1_pieces.num_pieces;
    struct piece *top = board[userRow][userColumn].stack; //storing the entire stack of the source square(the colour and *next piece) into a pointer.

    struct piece *curr = top;
    /*looping through until it gets to the last piece of the stack*/
    while (curr->next != NULL) {
        curr = curr->next;
    }

    /*Since the last piece of the the stack . next is already NULL, when making a move, I set the last piece.next to
     * equal the top piece of the stack I am moving to. Then I set the top piece of the square I move to, to equal the top piece
     * from the square I moved from. Then I set the stack I moved from to NULL.*/
    curr->next = board[userRow][userColumn - currentNumberOfPieces].stack;
    board[userRow][userColumn - currentNumberOfPieces].stack = top;
    board[userRow][userColumn - currentNumberOfPieces].num_pieces = tempNumPieces + currentNumberOfPieces;
    board[userRow][userColumn].num_pieces = 0;
    board[userRow][userColumn].stack = NULL;
    //square testValue = board[userRow][userColumn - currentNumberOfPieces];

    //if the number of pieces of a square is greater than five, this means a pop operation has to happen, then the removeLeft function is called.
    if(board[userRow][userColumn - currentNumberOfPieces].num_pieces > 5)
    {
        removeLeft(board, userRow, userColumn, currentNumberOfPieces, players, playerIndex);
    }
}
square moveItemsRight(square board[BOARD_SIZE][BOARD_SIZE], int userRow, int userColumn, int currentNumberOfPieces, player players[2], int playerIndex)
{
    square num1_pieces = board[userRow][userColumn + currentNumberOfPieces]; //storing the location of the square we are moving to
    int tempNumPieces = num1_pieces.num_pieces;
    struct piece *top = board[userRow][userColumn].stack; //storing the entire stack of the source square(the colour and *next piece) into a pointer.

    struct piece *curr = top;
    /*looping through until it gets to the last piece of the stack*/
    while(curr->next != NULL) {
        curr = curr->next;
    }

    /*Since the last piece of the the stack . next is already NULL, when making a move, I set the last piece.next to
     * equal the top piece of the stack I am moving to. Then I set the top piece of the square I move to, to equal the top piece
     * from the square I moved from. Then I set the stack I moved from to NULL.*/
    curr->next = board[userRow][userColumn + currentNumberOfPieces].stack;
    board[userRow][userColumn + currentNumberOfPieces].stack = top;
    board[userRow][userColumn + currentNumberOfPieces].num_pieces = tempNumPieces + currentNumberOfPieces;
    board[userRow][userColumn].num_pieces = 0;
    board[userRow][userColumn].stack = NULL;

    //if the number of pieces of a square is greater than five, this means a pop operation has to happen, then the removeRight function is called.
    if(board[userRow][userColumn + currentNumberOfPieces].num_pieces > 5)
    {
        removeRight(board, userRow, userColumn, currentNumberOfPieces, players, playerIndex);
    }
}
square moveItemsUp(square board[BOARD_SIZE][BOARD_SIZE], int userRow, int userColumn, int currentNumberOfPieces, player players[2], int playerIndex)
{
    square num1_pieces = board[userRow - currentNumberOfPieces][userColumn]; //storing the location of the square we are moving to
    int tempNumPieces = num1_pieces.num_pieces;
    struct piece *top = board[userRow][userColumn].stack; //storing the entire stack of the source square(the colour and *next piece) into a pointer.

    struct piece *curr = top;
    /*looping through until it gets to the last piece of the stack*/
    while(curr->next != NULL) {
        curr = curr->next;
    }

    /*Since the last piece of the the stack . next is already NULL, when making a move, I set the last piece.next to
     * equal the top piece of the stack I am moving to. Then I set the top piece of the square I move to, to equal the top piece
     * from the square I moved from. Then I set the stack I moved from to NULL.*/
    curr->next = board[userRow - currentNumberOfPieces][userColumn].stack;
    board[userRow - currentNumberOfPieces][userColumn].stack = top;
    board[userRow - currentNumberOfPieces][userColumn].num_pieces = tempNumPieces + currentNumberOfPieces;
    board[userRow][userColumn].num_pieces = 0;
    board[userRow][userColumn].stack = NULL;

    //if the number of pieces of a square is greater than five, this means a pop operation has to happen, then the removeUp function is called.
    if(board[userRow - currentNumberOfPieces][userColumn].num_pieces > 5)
    {
        removeUp(board, userRow, userColumn, currentNumberOfPieces, players, playerIndex);
    }
}
square moveItemsDown(square board[BOARD_SIZE][BOARD_SIZE], int userRow, int userColumn, int currentNumberOfPieces, player players[2], int playerIndex)
{

    square num1_pieces = board[userRow + currentNumberOfPieces][userColumn]; //storing the location of the square we are moving to
    int tempNumPieces = num1_pieces.num_pieces;
    struct piece *top = board[userRow][userColumn].stack; //storing the entire stack of the source square(the colour and *next piece) into a pointer.

    struct piece *curr = top;
    /*looping through until it gets to the last piece of the stack*/
    while(curr->next != NULL) {
        curr = curr->next;
    }

    /*Since the last piece of the the stack . next is already NULL, when making a move, I set the last piece.next to
     * equal the top piece of the stack I am moving to. Then I set the top piece of the square I move to, to equal the top piece
     * from the square I moved from. Then I set the stack I moved from to NULL.*/
    curr->next = board[userRow + currentNumberOfPieces][userColumn].stack;
    board[userRow + currentNumberOfPieces][userColumn].stack = top;
    board[userRow + currentNumberOfPieces][userColumn].num_pieces = tempNumPieces + currentNumberOfPieces;
    board[userRow][userColumn].num_pieces = 0;
   board[userRow][userColumn].stack = NULL;

   //if the number of pieces of a square is greater than five, this means a pop operation has to happen, then the removeDown function is called.
    if(board[userRow + currentNumberOfPieces][userColumn].num_pieces > 5)
    {
        removeDown(board, userRow, userColumn, currentNumberOfPieces, players, playerIndex);
    }
}
