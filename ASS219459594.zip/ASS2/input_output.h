//
// Created by bomte on 27/03/2020.
//

#ifndef ASS2_INPUT_OUTPUT_H
#define ASS2_INPUT_OUTPUT_H

#include "sizes.h"
#include "startGame.h"
#include <stdbool.h>

//Function to print the board
void print_board(square board[BOARD_SIZE][BOARD_SIZE]);
void print_players(player players[PLAYERS_NUM]);
void managePlayers(player players[PLAYERS_NUM], square board[BOARD_SIZE][BOARD_SIZE]);
bool findWinner(square board[BOARD_SIZE][BOARD_SIZE], player players[PLAYERS_NUM]);
void movingDirections(player players[2], square board[8][8], int userRow, int userColumn, int indexNumber);


#endif //ASS2_INPUT_OUTPUT_H
