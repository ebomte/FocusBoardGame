//
// Created by bomte on 27/03/2020.
//

#ifndef ASS2_SIZES_H
#define ASS2_SIZES_H

#define BOARD_SIZE 8
#define PLAYERS_NUM 2

#endif //ASS2_SIZES_H
