//
// Created by bomte on 03/04/2020.
//

#ifndef ASS2_STACKINIT_H
#define ASS2_STACKINIT_H
#include "sizes.h"
#include "startGame.h"
#include "input_output.h"

square moveItemsLeft(square board[BOARD_SIZE][BOARD_SIZE], int userRow, int userColumn, int currentNumberOfPieces, player players[PLAYERS_NUM], int playerIndex);
square moveItemsRight(square board[BOARD_SIZE][BOARD_SIZE], int userRow, int userColumn, int currentNumberOfPieces, player players[PLAYERS_NUM], int playerIndex);
square moveItemsUp(square board[BOARD_SIZE][BOARD_SIZE], int userRow, int userColumn, int currentNumberOfPieces, player players[PLAYERS_NUM], int playerIndex);
square moveItemsDown(square board[BOARD_SIZE][BOARD_SIZE], int userRow, int userColumn, int currentNumberOfPieces, player players[PLAYERS_NUM], int playerIndex);

#endif //ASS2_STACKINIT_H
