#include <stdio.h>
#include <stdlib.h>
#include "input_output.h"
#include "sizes.h"
#include "stackInit.h"
#include "startGame.h"

int main(void)
{
    // declaration of the players and the board
    player players[PLAYERS_NUM];
    square board[BOARD_SIZE][BOARD_SIZE];

    initialize_players(players);

    initialize_board(board);

    print_board(board);

    print_players(players);

    //printingDetails(color );

    managePlayers(players,board);
    return 0;
}
