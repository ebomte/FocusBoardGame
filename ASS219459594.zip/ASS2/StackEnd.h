//
// Created by bomte on 20/04/2020.
//

#ifndef ASS2_STACKEND_H
#define ASS2_STACKEND_H

#include "sizes.h"
#include "startGame.h"
void removeLeft(square board[BOARD_SIZE][BOARD_SIZE], int userRow, int userColumn, int currentNumberOfPieces, player players[PLAYERS_NUM], int playerIndex);
void removeRight(square board[BOARD_SIZE][BOARD_SIZE], int userRow, int userColumn, int currentNumberOfPieces, player players[PLAYERS_NUM], int playerIndex);
void removeUp(square board[BOARD_SIZE][BOARD_SIZE], int userRow, int userColumn, int currentNumberOfPieces, player players[PLAYERS_NUM], int playerIndex);
void removeDown(square board[BOARD_SIZE][BOARD_SIZE], int userRow, int userColumn, int currentNumberOfPieces, player players[PLAYERS_NUM], int playerIndex);

//void removePieces(square board[BOARD_SIZE][BOARD_SIZE], int userRow, int userColumn, int currentNumberOfPieces);

#endif //ASS2_STACKEND_H
